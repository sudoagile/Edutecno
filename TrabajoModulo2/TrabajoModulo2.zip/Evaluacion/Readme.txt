Profesor, la web permite escrbir el nombre del digimon y si es correcto muestra la imagen y el nivel,
Si es nombre no está correcto muestra a un digimon llorando
Igual muestra y oculta la lista 